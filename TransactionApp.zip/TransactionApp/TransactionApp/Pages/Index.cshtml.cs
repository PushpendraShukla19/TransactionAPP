using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data;
using TransactionApp.Model;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TransactionApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

       
        [BindProperty]
        public TransactionDetails TransactionDetails { get; set; }


        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public List<TransactionList> TransactionDetailsList { get; set; }

        public void OnGet()
        {
            DateTime currentDate = DateTime.Now;
            TransactionDetailsList = new List<TransactionList>();

            string connectionString = "Data Source=LAPTOP-2T6RF34T;Initial Catalog=TransactionApp;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("GetTransactionDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Date", currentDate);
                cmd.Parameters.AddWithValue("@Type", 1);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            TransactionList transactionDetails = new TransactionList();

                            transactionDetails.TransactionType = reader["TransactionType"].ToString();
                            if (transactionDetails.TransactionType == "Debit")
                            {
                                transactionDetails.Debit = Convert.ToDecimal(reader["Debit"]);
                            }
                            else
                            {
                                transactionDetails.Credit = Convert.ToDecimal(reader["Credit"]);
                            }
                            transactionDetails.Description = reader["Descriptions"].ToString();
                            transactionDetails.CreatedDate =Convert.ToDateTime(reader["CreatedDate"]);

                            transactionDetails.RunningBalance =(decimal) reader["RunningBalanace"];
                            TransactionDetailsList.Add(transactionDetails);
                        }
                    }
                }

                conn.Close();
            }
        }

        public void OnPost()
        {
            string connectionString = "Data Source=LAPTOP-2T6RF34T;Initial Catalog=TransactionApp;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SaveTransactionDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameters to the command
                // Add parameters to the command
                cmd.Parameters.AddWithValue("@TransactionType", TransactionDetails.TransactionType);
                cmd.Parameters.AddWithValue("@Amount", TransactionDetails.Amount);
                cmd.Parameters.AddWithValue("@Description", TransactionDetails.Description);

                // Execute the stored procedure
                int rowsAffected = cmd.ExecuteNonQuery();


                // No need to use SqlDataReader here, as ExecuteNonQuery() suffices for INSERT operations

                conn.Close();
                OnGet();
            }
        }

    }
}
